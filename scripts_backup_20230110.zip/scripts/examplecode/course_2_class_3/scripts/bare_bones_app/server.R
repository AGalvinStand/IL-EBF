# bare bones server example
# 2022-10-04

# load -------

library(tidyverse)
library(shiny)
library(leaflet)
library(scales)
library(viridis)
library(plotly)
library(sf)

shinyServer(function(input, output, session){

  
})

